<!-- <form action="<?php echo e(url('user/save')); ?>" method="post"> -->

<?php $__env->startSection('content'); ?>

<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">

            <!-- Page body start -->
            <div class="page-body">
                <div class="row">

                    <div class="col-sm-12">
                        <!-- Basic Form Inputs card start -->
                        <div class="card" style="margin-bottom: 5px;">
                            <div class="card-header">


                            </div>
                            <div class="card-block" style="padding-bottom: 5px;">

                                <form action="<?php echo e(route('bank.store')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row">

                                        <div class="col-sm-4">
                                            <label class="col-form-label">Bank Name</label>
                                            <input type="text" name='txtBank' class="form-control form-control-round"
                                                placeholder="Bank Name" autocomplete="off">
                                        </div>
                                        <div class="col-sm-4">
                                            <label class="col-form-label">Brach Name</label>
                                            <input type="text" name='txtBrach' class="form-control form-control-round"
                                                placeholder="Email">
                                        </div>
                                        <div class="col-sm-4">
                                            <label class="col-form-label">Brach Address</label>
                                            <input type="text" name='txtAddress' class="form-control form-control-round"
                                                placeholder="Address">
                                        </div>
                                    </div>

                                    <div class="form-group row">

                                        <div class="col-sm-2">
                                            <input type="submit" name='btnCreate'
                                                class="form-control form-control-round btn-primary" value='Submit'>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                        <!-- Basic Form Inputs card end -->
                    </div>
                </div>
            </div>
            <!-- Page body end -->


            <!-- Main-body start -->

            <div class="card">
                <div class="card-block table-border-style">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr class='table-info'>

                                    <th>#</th>
                                    <th>Bank Name</th>
                                    <th>Brach</th>
                                    <th>Address</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bnk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($bnk->id); ?></td>
                                    <td><?php echo e($bnk->name); ?></td>
                                    <td><?php echo e($bnk->branch); ?></td>
                                    <td><?php echo e($bnk->branch_address); ?></td>
                                    <td>

                                        <div style="display:flex">
                                            <button style='border:none;  padding:5px;'
                                                class="btn btn-default waves-effect" data-toggle="tooltip"
                                                data-placement="top" title="" data-original-title="To Update User"><a
                                                    href="<?php echo e(route('users.edit',$bnk->id)); ?>"><i class='fa fa-pencil'></i>
                                                    Edit<a></button>
                                            <button style='border:none;  padding:5px;'
                                                class="btn btn-default waves-effect" data-toggle="tooltip"
                                                data-placement="top" title="" data-original-title="View User Details">
                                                <a href="<?php echo e(route('users.show',$bnk->id)); ?>"><i class='fa fa-eye'></i>
                                                    Details<a></button>
                                            <button style='border:none;'>
                                                <form action="<?php echo e(route('users.destroy',$bnk->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field("DELETE"); ?>
                                                    <i class='fa fa-trash'></i><input type="submit" name="btnDelete"
                                                        value="Delete" style='border:none; padding:6px;'
                                                        class="btn btn-default waves-effect" data-toggle="tooltip"
                                                        data-placement="top" title=""
                                                        data-original-title="To Delete User" />
                                                </form>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main-body end -->
<div id="styleSelector">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project\resources\views/pages/bank/create_bank.blade.php ENDPATH**/ ?>