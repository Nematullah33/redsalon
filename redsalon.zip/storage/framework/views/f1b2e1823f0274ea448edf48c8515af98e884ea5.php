
<?php $__env->startSection('title', 'Reports'); ?>
<?php $__env->startSection('content'); ?>
<style>
.table td {
    padding: 10px;
}

.table th {
    padding: 10px;
}
</style>


<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
            <div class="card">
                <div class="card-header">
                    <h5> Reports </h5>

                    <div class="card-header-right">
                        <ul class="list-unstyled card-option">
                            <li><i class="fa fa fa-wrench open-card-option"></i></li>
                            <li><i class="fa fa-window-maximize full-card"></i></li>
                            <li><i class="fa fa-minus minimize-card"></i></li>
                            <li><i class="fa fa-refresh reload-card"></i></li>
                            <li><i class="fa fa-trash close-card"></i></li>
                        </ul>
                    </div>
                </div>
                <div class="card-block table-border-style">
                    <form action="">
                        <div class="form-group row">
                            <div class="col-sm-3">
                                <label class="form-label">From</label>
                                <input type="date" name='formOrder'
                                    class="form-control" value="<?php echo date('Y-m-d');?>" />
                            </div>
                            <div class="col-sm-3">
                                <label class="form-label">To</label>
                                <input type="date" name='toOrder'
                                    class="form-control" value="<?php echo date('Y-m-d');?>"/>
                            </div>
                            <div class="col-sm-3">
                                <div style="margin-bottom:8px;"></div><br>
                                <button type="submit" style="padding: 4px 15px;" class=" btn-outline-primary">Search  <i class="fa fa-search"></i></button>
                                
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(url('reports')); ?>" style="padding: 4px 15px;"  class="btn-outline-primary">Refresh</a>
                            </div>
                        </div>
                    </form>
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                          <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Product Sale</a>
                          <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Service Sale</a>
                          <a class="nav-item nav-link" id="nav-transaction-tab" data-toggle="tab" href="#nav-purchase" role="tab" aria-controls="nav-purchase" aria-selected="false">Purchase</a>
                          <a class="nav-item nav-link" id="nav-transaction-tab" data-toggle="tab" href="#nav-payment" role="tab" aria-controls="nav-payment" aria-selected="false">Payment</a>
                          <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Expense</a>
                          
                          <a class="nav-item nav-link" id="nav-transaction-tab" data-toggle="tab" href="#nav-transaction" role="tab" aria-controls="nav-transaction" aria-selected="false">Profit And Loss</a>
                        </div>
                      </nav>
                      <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                            <div class="table-responsive">
                                <div style="float: right; padding:5px;">
                                    <form action="<?php echo e(route('salesreport.print')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="from" value="<?php echo e($from); ?>">
                                        <input type="hidden" name="to" value="<?php echo e($to); ?>">
                                        <input type="submit" class="" value="Print">
                                    </form>
                                </div>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr class="table-primary text-white">
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Number Of Transaction</th>
                                            <th>Total Sale</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <input type="hidden" value="<?php echo e($total=0); ?>">
                                            <?php
                                                $sn=1;
                                                $sale_total=0;
                                            ?>
                                        <?php $__currentLoopData = $dailySales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dailySale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($sn++); ?></td>
                                            <td><?php echo e($dailySale->Date); ?></td>
                                            <td><?php echo e($dailySale->no_of_transactions); ?></td>
                                            <td><?php echo e($dailySale->total_sale); ?></td>
   
                                        </tr>
                                        
                                        <?php
                                            $sale_total+=$dailySale->total_sale;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td></td>
                                            <td></td>
                                            <td class="text-right text-info"><b>Total </b></td>
                                            <td class="text-info"><b><?php echo e($sale_total); ?></b></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <div class="table-responsive">
                                <div style="float: right; padding:5px;">
                                    <form action="<?php echo e(route('servicesale.pdf')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="from" value="<?php echo e($from); ?>">
                                        <input type="hidden" name="to" value="<?php echo e($to); ?>">
                                        <input type="submit" class="" value="Print">
                                    </form>
                                </div>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr class="table-primary text-white">
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Number Of Transaction</th>
                                            <th>Total Service Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <input type="hidden" value="<?php echo e($total=0); ?>">
                                        <tr>
                                            <?php
                                                $sn=1;
                                                $service_sale_total=0;
                                            ?>
                                            <?php $__currentLoopData = $dailyServiceSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ServiceSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($sn++); ?></td>
                                            <td><?php echo e($ServiceSale->Date); ?></td>
                                            <td><?php echo e($ServiceSale->no_of_transactions); ?></td>
                                            <td><?php echo e($ServiceSale->total_sale); ?></td>
                                            
                                            
                                        </tr>
                                        
                                        <?php
                                            $service_sale_total+=$ServiceSale->total_sale;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td></td>
                                            <td></td>
                                            <td class="text-right text-info"><b>Total </b></td>
                                            <td class="text-info"><b><?php echo e($service_sale_total); ?></b></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-purchase" role="tabpanel" aria-labelledby="nav-purchase-tab">
                            <div class="table-responsive">
                                <div style="float: right; padding:5px;">
                                    <form action="<?php echo e(route('purchase.pdf')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="from" value="<?php echo e($from); ?>">
                                        <input type="hidden" name="to" value="<?php echo e($to); ?>">
                                        <input type="submit" class="" value="Print">
                                    </form>
                                </div>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr class="table-primary text-white">
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Number Of Transaction</th>
                                            <th>Total Purchase Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <input type="hidden" value="<?php echo e($total=0); ?>">
                                        <tr>
                                            <?php
                                                $sn=1;
                                                $purchase_total=0;
                                            ?>
                                            <?php $__currentLoopData = $dailyPurchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dailyPurch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($sn++); ?></td>
                                            <td><?php echo e($dailyPurch->Date); ?></td>
                                            <td><?php echo e($dailyPurch->no_of_transactions); ?></td>
                                            <td><?php echo e($dailyPurch->total_purchase); ?></td>
                                            
                                            
                                        </tr>
                                        
                                        <?php
                                            $purchase_total+=$dailyPurch->total_purchase;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td></td>
                                            <td></td>
                                            <td class="text-right text-info"><b>Total </b></td>
                                            <td class="text-info"><b><?php echo e($purchase_total); ?></b></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-payment" role="tabpanel" aria-labelledby="nav-payment-tab">
                            <table class="table table-bordered">
                                <div style="float: right; padding:5px;">
                                    <form action="<?php echo e(route('payment.report')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="from" value="<?php echo e($from); ?>">
                                        <input type="hidden" name="to" value="<?php echo e($to); ?>">
                                        <input type="submit" class="" value="Print">
                                    </form>
                                </div>
                                <thead>
                                    <tr class="table-primary text-white">
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Number Of Transaction</th>
                                        <th>Total Expense Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <input type="hidden" value="<?php echo e($total=0); ?>">
                                    <tr>
                                        <?php
                                            $sn=1;
                                            $payment_total=0;
                                        ?>
                                        <?php $__currentLoopData = $dailypayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dailypayment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($sn++); ?></td>
                                        <td><?php echo e($dailypayment->Date); ?></td>
                                        <td><?php echo e($dailypayment->no_of_transactions); ?></td>
                                        <td><?php echo e($dailypayment->total_paymnet); ?></td>
                                        
                                        
                                    </tr>
                                    
                                    <?php
                                        $payment_total+=$dailypayment->total_paymnet;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td></td>
                                        <td></td>
                                        <td class="text-right text-info"><b>Total </b></td>
                                        <td class="text-info"><b><?php echo e($payment_total); ?></b></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                            <table class="table table-bordered">
                                <div style="float: right; padding:5px;">
                                    <form action="<?php echo e(route('expense.report')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="from" value="<?php echo e($from); ?>">
                                        <input type="hidden" name="to" value="<?php echo e($to); ?>">
                                        <input type="submit" class="" value="Print">
                                    </form>
                                </div>
                                <thead>
                                    <tr class="table-primary text-white">
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Number Of Transaction</th>
                                        <th>Total Expense Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <input type="hidden" value="<?php echo e($total=0); ?>">
                                    <tr>
                                        <?php
                                            $sn=1;
                                            $expense_total=0;
                                        ?>
                                        <?php $__currentLoopData = $dailyexpenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dailyexp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($sn++); ?></td>
                                        <td><?php echo e($dailyexp->Date); ?></td>
                                        <td><?php echo e($dailyexp->no_of_transactions); ?></td>
                                        <td><?php echo e($dailyexp->total_expense); ?></td>
                                        
                                        
                                    </tr>
                                    
                                    <?php
                                        $expense_total+=$dailyexp->total_expense;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td></td>
                                        <td></td>
                                        <td class="text-right text-info"><b>Total </b></td>
                                        <td class="text-info"><b><?php echo e($expense_total); ?></b></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="tab-pane fade" id="nav-transaction" role="tabpanel" aria-labelledby="nav-transaction-tab">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6 offset-3">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr class="">
                                                        <th>Product Sales</th>
                                                        <th>:</th>
                                                        <th><?php echo e($sale_total); ?></th>
                                                    </tr>
                                                    <tr class="">
                                                        <th>Service Sales</th>
                                                        <th>:</th>
                                                        <th ><?php echo e($service_sale_total); ?></th>
                                                    </tr>
                                                    <tr class="">
                                                        <th>Purchases</th>
                                                        <th>:</th>
                                                        <th ><?php echo e($purchase_total); ?></th>
                                                    </tr>
                                                    <tr>    
                                                        <th>Supplier Payments</th>
                                                        <th>:</th>
                                                        <th ><?php echo e($payment_total); ?></th>
                                                    </tr>
                                                    <tr>    
                                                        <th>Expenses</th>
                                                        <th>:</th>
                                                        <th ><?php echo e($expense_total); ?></th>
                                                    </tr>
                                                    <tr>   
                                                        <th>Gross Profit</th>
                                                        <th>:</th>
                                                        <th id='show-profit'></th>
                                                    </tr>
                                                </thead>
                                                
                                            </table>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            
                        </div>
                      </div>
                      <?php
                            $income=$sale_total+$service_sale_total;
                            $loss=$payment_total+$expense_total;
                            $grossprofit=$income-$loss;
                      ?>
                    <input type="hidden" name="" id="income" value="<?php echo e($income+$advance_booking[0]->advance); ?>">
                    <input type="hidden" name="" id="loss" value="<?php echo e($loss); ?>">
                    <input type="hidden" name="" id="profit" value="<?php echo e($grossprofit); ?>">
                </div>
            </div>
        </div>
        
    </div>
</div>
<script>
    $(function(){
        let income= $("#income").val();
        let loss= $("#loss").val();
        let profit= $("#profit").val();
        $("#show-income").html(income);
        $("#show-loss").html(loss);
        $("#show-profit").html(profit);

        
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\redsalon\resources\views/pages/reports/make_report.blade.php ENDPATH**/ ?>