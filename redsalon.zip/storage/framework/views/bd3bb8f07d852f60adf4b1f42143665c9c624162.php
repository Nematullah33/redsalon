<nav class="pcoded-navbar">
    <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
    <div class="pcoded-inner-navbar main-menu">
        <div class="">
            <div class="main-menu-header">
            <img class="img-80 img-radius" src="<?php echo e(asset('img')); ?>/<?php echo e(session('sess_img_photo')); ?>" alt="User-Profile-Image">
                <div class="user-details">
                    <span id="more-details"><?php echo e(session('sess_user_name')); ?><i class="fa fa-caret-down"></i></span>
                </div>
            </div>
            <div class="main-menu-content">
                <ul>
                    <li class="more-details">
                        
                        <a href="<?php echo e(url('logout')); ?>"><i class="ti-layout-sidebar-left"></i>Logout</a>
                    </li>
                </ul>
            </div>
        </div>
        
        <ul class="pcoded-item pcoded-left-item">
            <li class="active">
                <a href="<?php echo e(url('/home')); ?>" class="waves-effect waves-dark">
                    <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                    <span class="pcoded-mtext">Dashboard</span>
                    <span class="pcoded-mcaret"></span>
                </a>
            </li>
        </ul>
        
        <?php $__currentLoopData = $menumaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
            <?php if($menu->menu_name == 'Bookings'): ?>
                <?php echo $__env->make('layout.erp.menus.booking_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Sales'): ?>
            <?php echo $__env->make('layout.erp.menus.order_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Customers'): ?>
                <?php echo $__env->make('layout.erp.menus.buyer_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Suppliers'): ?>
            <?php echo $__env->make('layout.erp.menus.supplier_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Services'): ?>
            <?php echo $__env->make('layout.erp.menus.service_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Products'): ?>
            <?php echo $__env->make('layout.erp.menus.product_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if($menu->menu_name == 'Expense'): ?>
            <?php echo $__env->make('layout.erp.menus.expense_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Categories'): ?>
            <?php echo $__env->make('layout.erp.menus.category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Stocks'): ?>
                <?php echo $__env->make('layout.erp.menus.stock_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Purchases'): ?>
                <?php echo $__env->make('layout.erp.menus.purchase_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Payments'): ?>
                <?php echo $__env->make('layout.erp.menus.payment_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Users'): ?>
                <?php echo $__env->make('layout.erp.menus.user_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if($menu->menu_name == 'Reports'): ?>
                <?php echo $__env->make('layout.erp.menus.report_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>
</nav><?php /**PATH C:\xampp\htdocs\redsalon\resources\views/layout/erp/sidebar.blade.php ENDPATH**/ ?>