<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Sale Pdf</title>
    <style>
        .table-responsive {
            display: inline-block;
            width: 100%;
            overflow-x: auto;
        }
        table {
            border-collapse: collapse;
        }
        table tr td{
            border:1px solid #ccc; 
            padding: 5px;
        }
        table tr th{
            border:1px solid #ccc; 
            padding: 5px;
        }
    </style>
</head>
<body>
                    <div style="text-align: center;">
                        <img src="<?php echo e(public_path('img/setting/'.$site->photo)); ?>" style="width:50px;">
                        <p>Company Name: <?php echo e($site->name); ?> <br>
                        Mobile: <?php echo e($site->mobile); ?> <br>
                        Email: <?php echo e($site->email); ?> <br>
                        Address: <?php echo e($site->address); ?></p>
                    </div>
                    <div>Sales List</div>
                    <div><?php echo e($from); ?> <?php if($from!=''){ echo "To ";}?> <?php echo e($to); ?></div>
                <div class="table-responsive">
                    <table class="table table-bordered" style="width: 100%">
                        <tr style="background-color: #ccc;">
                            <th>#</th>
                            <th>Sale Date</th>
                            <th>Customer Name</th>
                            <th>Mobile</th>
                            <th>Paid Amount</th>
                            
                            
                        </tr>
                            <?php
                             $sn=1;
                             $total=0;
                            ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td><?php echo e($sn++); ?></td>
                                    <td><?php echo e($order->order_date); ?></td>
                                    <td><?php echo e($order->cus_name); ?></td>
                                    <td><?php echo e($order->mobile); ?></td>
                                    <td><?php echo e($order->paid_amount); ?></td>
                                     
                                
                                </tr>
                                <?php echo e($total+=$order->paid_amount); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="4" style="text-align: right"><b> Total </b></td>
                                <td><b><?php echo e($total); ?> </b></td>
                            </tr>
                    </table>
                </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\redsalon\resources\views/pages/pdf/order_report.blade.php ENDPATH**/ ?>