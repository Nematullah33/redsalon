<h2>Manage User</h2>
<a href="<?php echo e(route('users.create')); ?>">Create</a>
<style>
    table tr td{
        border-collapse:collapse;
        border:1px solid #000;
        padding:10px;
    }
    table tr th{
        border-collapse:collapse;
        border:1px solid #000;
        padding:10px;
        background-color:#f9973c;
    }
    table{
        margin: 0 auto;
        background-color:#f9b87b;
    }
    a{
        text-decoration:none;
    }
</style>
<table>
<tr>
    <th>ID</th>
    <th>Role</th>
    <th>Name</th>
    <th>Email</th>
    <th>Photo</th>
    <th>Action</th>
</tr>
<tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <td><?php echo e($user->id); ?></td>
    <td><?php echo e($user->role); ?></td>
    <td><?php echo e($user->username); ?></td>
    <td><?php echo e($user->email); ?></td>
    <td><img src="<?php echo e(asset('img')); ?>/<?php echo e($user->photo); ?>" alt="" width='100'></td>

    <td>
        <div style="display:flex">
            <button><a style="flex:1 1 0" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit<a></button>
            <button> <a style="flex:1 1 0" href="<?php echo e(route('users.show',$user->id)); ?>">Details<a></button>
            <button style="background-color:red;"><form style="flex:1 1 0" action="<?php echo e(route('users.destroy',$user->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field("DELETE"); ?>            
                <input type="submit" name="btnDelete" value="Delete" />
            </form></button>
       </div>
    </td>
    
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH D:\xampp\htdocs\laravel\project\resources\views/user/manage_user.blade.php ENDPATH**/ ?>