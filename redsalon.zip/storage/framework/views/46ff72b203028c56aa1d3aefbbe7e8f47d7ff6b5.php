
<?php $__env->startSection('content'); ?>
<style>
    .table td{
        padding: 10px;
    } 
    .table th {
    padding: 10px;
    }
</style>
<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('product.create')); ?>">
                        <h5>Create Product</h5>
                    </a>

                    <div class="card-header-right">
                        <ul class="list-unstyled card-option">
                            <li><i class="fa fa fa-wrench open-card-option"></i></li>
                            <li><i class="fa fa-window-maximize full-card"></i></li>
                            <li><i class="fa fa-minus minimize-card"></i></li>
                            <li><i class="fa fa-refresh reload-card"></i></li>
                            <li><i class="fa fa-trash close-card"></i></li>
                        </ul>
                    </div>
                </div>
                <div class="card-block table-border-style">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr class='table-info'>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>price</th>
                                    <th>Photo</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($pro->id); ?></td>
                                    <td><?php echo e($pro->name); ?></td>
                                    <td><?php echo e($pro->price); ?></td>
                                    <td><img src="<?php echo e(asset('img/product')); ?>/<?php echo e($pro->photo); ?>" width='70' alt="<?php echo e($pro->photo); ?>"></td>
                                    <td>

                                        <div style="display:flex">
                                            <button style='border:none;  padding:5px;' class="btn btn-default waves-effect" data-toggle="tooltip" data-placement="top" title="" data-original-title="To Update User" ><a 
                                                    href="<?php echo e(route('product.edit',$pro->id)); ?>"><i class='fa fa-pencil'></i> Edit<a></button>
                                            <button style='border:none;  padding:5px;' class="btn btn-default waves-effect" data-toggle="tooltip" data-placement="top" title="" data-original-title="View User Details"  > <a 
                                                    href="<?php echo e(route('product.show',$pro->id)); ?>"><i class='fa fa-eye'></i>  Details<a></button>
                                            <button style='border:none;'>
                                                <form  action="<?php echo e(route('product.destroy',$pro->id)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field("DELETE"); ?>
                                                    <i class='fa fa-trash'></i><input type="submit" name="btnDelete" value="Delete" style='border:none; padding:6px;' class="btn btn-default waves-effect" data-toggle="tooltip" data-placement="top" title="" data-original-title="To Delete User" />
                                                </form>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project\resources\views/pages/product/manage_product.blade.php ENDPATH**/ ?>