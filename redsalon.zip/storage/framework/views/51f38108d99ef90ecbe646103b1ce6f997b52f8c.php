
<?php $__env->startSection('title', 'Service Sales List'); ?>
<?php $__env->startSection('content'); ?>
<style>
.table td {
    padding: 10px;
}

.table th {
    padding: 10px;
}
</style>
<div class="addEmployeeModal modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="user_form">
                <div class="modal-header">
                    <h4 class="modal-title">Update Status</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">

                <select id="cmbStatus" name="cmbStatus" class="form-control" >
                    <option value="1">On Process</option>
                    <option value="2">On the way</option>
                    <option value="3">Delidered</option>
                </select>

                </div>
                <div class="modal-footer">
                    <input type="hidden" value="1" name="type">
                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                    <button type="button" class="btn btn-success" id="btnSubmit">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('servicesale.create')); ?>">
                        <h5><i class="fa fa-plus btn btn-primary">  New Service Sale </i></h5>
                    </a>

                    <div class="card-header-right">
                        <ul class="list-unstyled card-option">
                            <li><i class="fa fa fa-wrench open-card-option"></i></li>
                            <li><i class="fa fa-window-maximize full-card"></i></li>
                            <li><i class="fa fa-minus minimize-card"></i></li>
                            <li><i class="fa fa-refresh reload-card"></i></li>
                            <li><i class="fa fa-trash close-card"></i></li>
                        </ul>
                    </div>
                </div>
                <div class="card-block table-border-style">
                    <form action="">
                        <div class="form-group row">
                            <div class="col-sm-3">
                                <label class="form-label">From</label>
                                <input type="date" name='formOrder'
                                    class="form-control" value="<?php echo date('Y-m-d');?>" />
                            </div>
                            <div class="col-sm-3">
                                <label class="form-label">To</label>
                                <input type="date" name='toOrder'
                                    class="form-control" value="<?php echo date('Y-m-d');?>"/>
                            </div>
                            <div class="col-sm-2">
                                <div style="margin-bottom:8px;"></div><br>
                                <button type="submit" style="padding: 4px 15px;" class=" btn-outline-primary">Search  <i class="fa fa-search"></i></button>
                                
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(url('servicesale')); ?>" style="padding: 4px 15px;"  class="btn-outline-primary">Referesh</a>
                            </div>
                        </form>    
                            <div class="col-sm-1">
                                <div class="pl-3">
                                    <form action="<?php echo e(route('servicesale.print')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="from" value="<?php echo e($from); ?>">
                                        <input type="hidden" name="to" value="<?php echo e($to); ?>">
                                        <input type="submit" class="" value="Print">
                                    </form>
                                </div>
                            </div>
                        </div>
                    

                    <?php if(Session::has('delete_order')): ?>
                            <div class="alert alert-success d-flex align-items-center" role="alert">
                            <?php echo e(Session::get('delete_order')); ?>        
                            </div>
                        <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr class='table-info'>
                                    <th>#</th>
                                    <th>Sale Date</th>
                                    <th>Customer Name</th>
                                    <th>Mobile</th>
                                    <th>Total Amount</th>
                                    <th>Advance</th>
                                    <th>Discount</th>
                                    <th>Paid Amount</th>
                                    
                                    
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody> <?php $sn=1; ?>
                                <tr>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($sn++); ?></td>
                                    <td><?php echo e($order->sale_date); ?></td>
                                    <td><?php echo e($order->cus_name); ?></td>
                                    <td><?php echo e($order->mobile); ?></td>
                                    <td><?php echo e($order->sale_total); ?></td>
                                    <td><?php echo e($order->advance); ?></td>
                                    
                                    <td><?php echo e($order->sale_total*$order->discount/100); ?> </td>
                                    <td><?php echo e($order->paid_amount); ?></td>
                                    
                                    
                                    <td>
                                        <div style="display:flex">
                                            <a href="<?php echo e(route('servicesale.show',$order->id)); ?>" style="padding:2px; border:1px solid hsl(177, 88%, 74%);"><i class="fa fa-eye btn btn-info" style="padding: 10px; "></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($orders instanceof \Illuminate\Pagination\LengthAwarePaginator): ?>
                        <?php echo e($orders->links()); ?>

                        <?php endif; ?>
                        
                    </div>
                </div>
            </div>
            <input type="hidden" name="" id="order_id">
        </div>
    </div>
</div>
<script>
    $(function(){
        $(".btnUpdate").on('click',function(){
            let order_id=$(this).data("id");
            $("#order_id").val(order_id);

        });
        
        $("#btnSubmit").on('click',function(){
            let id=$("#order_id").val(); 
            let status_id=$("#cmbStatus").val();
            
            $.ajax({
                url:"<?php echo e(route('update.order_status')); ?>",
                type:'get',
                data:{"status_id":status_id,"order_id":id},
                success:function(res){
                   
                 location.reload();
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\redsalon\resources\views/pages/servicesale/manage_servicesale.blade.php ENDPATH**/ ?>