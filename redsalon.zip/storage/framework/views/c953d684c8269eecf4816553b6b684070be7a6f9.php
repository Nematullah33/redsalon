<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Service Sale Pdf</title>
    <style>
        .table-responsive {
            display: inline-block;
            width: 100%;
            overflow-x: auto;
        }
        table {
            border-collapse: collapse;
        }
        table tr td{
            border:1px solid #ccc; 
            padding: 5px;
        }
        table tr th{
            border:1px solid #ccc; 
            padding: 5px;
        }
    </style>
</head>
<body>
                    <div style="text-align: center;">
                        <img src="<?php echo e(public_path('img/setting/'.$site->photo)); ?>" style="width:50px;">
                        <p>Company Name: <?php echo e($site->name); ?> <br>
                        Mobile: <?php echo e($site->mobile); ?> <br>
                        Email: <?php echo e($site->email); ?> <br>
                        Address: <?php echo e($site->address); ?></p>
                    </div>
                    
                    <div>Product Sale Report</div>
                    <div><?php echo e($from); ?> <?php if($from!=''){ echo "To ";}?> <?php echo e($to); ?></div>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tr style="background-color: #ccc;">
                            <th>#</th>
                            <th>Date</th>
                            <th>Number Of Transaction</th>
                            <th>Total Sale</th>
            
                        </tr>
                    <?php
                        $sn=1;
                        $sale_total=0;
                    ?>
                    <?php $__currentLoopData = $dailypayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dailypayment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($sn++); ?></td>
                        <td><?php echo e($dailypayment->Date); ?></td>
                        <td><?php echo e($dailypayment->no_of_transactions); ?></td>
                        <td><?php echo e($dailypayment->total_paymnet); ?></td>

                    </tr>
                    
                    <?php
                        $sale_total+=$dailypayment->total_paymnet;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td></td>
                        <td></td>
                        <td class="text-right text-info"><b>Total </b></td>
                        <td class="text-info"><b><?php echo e($sale_total); ?></b></td>
                    </tr>
                    </table>
                </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\redsalon\resources\views/pages/pdf/payment_report.blade.php ENDPATH**/ ?>