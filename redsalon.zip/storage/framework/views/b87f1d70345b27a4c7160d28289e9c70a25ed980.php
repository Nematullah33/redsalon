<!-- <form action="<?php echo e(url('user/save')); ?>" method="post"> -->
<a href="<?php echo e(url('/users')); ?>">Manage</a>
<form action="<?php echo e(route('users.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div>Role<br>
       <select name="cmbRole">
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
    </div>
    <div>Username<br>
      <input type="text" name="txtUsername" />
    </div>
    <div>Email<br>
      <input type="text" name="txtEmail" />
    </div>
    <div>Password<br>
      <input type="text" name="txtPassword" />
    </div>
    <div>Photo<br>
      <input type="file" name="filePhoto" />
    </div>
    <div>
      <input type="submit" name="btnCreate" value="Create" />
   </div>
</form>

<?php /**PATH D:\xampp\htdocs\laravel\project\resources\views/user/create_user.blade.php ENDPATH**/ ?>