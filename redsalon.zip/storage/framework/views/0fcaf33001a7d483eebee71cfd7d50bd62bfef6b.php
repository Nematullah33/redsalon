<form action="<?php echo e(url('user/save')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="txtName">
    <input type="submit" name="Submit">
</form><?php /**PATH D:\xampp\htdocs\laravel\project\resources\views/user/create.blade.php ENDPATH**/ ?>