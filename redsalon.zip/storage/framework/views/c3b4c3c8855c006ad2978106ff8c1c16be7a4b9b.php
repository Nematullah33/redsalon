
<?php $__env->startSection('content'); ?>
<style>
    .table td{
        padding: 10px;
    } 
    .table th {
    padding: 10px;
    }

</style>
<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
            <div class="card">
                <div class="card-header">
                            <a href="<?php echo e(route('customers.create')); ?>">
                                <h5><i class="fa fa-plus btn btn-primary">  New Buyer</i></h5>
                            </a>
                    <div class="card-header-right">
                        <ul class="list-unstyled card-option">
                            <li><i class="fa fa fa-wrench open-card-option"></i></li>
                            <li><i class="fa fa-window-maximize full-card"></i></li>
                            <li><i class="fa fa-minus minimize-card"></i></li>
                            <li><i class="fa fa-refresh reload-card"></i></li>
                            <li><i class="fa fa-trash close-card"></i></li>
                        </ul>
                    </div>
                </div>
                <div class="card-block table-border-style">
                    <div class="row">
                        <div class="col-md-10">
                            <form action="">
                                <div class="input-group mb-3">
                                    <input type="search" name="search" value="<?php echo e($search); ?>" class="form-control" placeholder="Search by name, phone, email" aria-label="Recipient's username" aria-describedby="button-addon2">
                                    <button class="btn btn-primary" type="submit" id="button-addon2"><i class="fa fa-search"></i></button>
                                  </div>
                            </form>
                        </div>
                    </div>
                    
                    
                    <div class="table-responsive">
                        <table class="table table-hover table-striped">
                            <thead>
                                <?php if(Session::has('delete_customer')): ?>
                                    <div class="alert alert-success d-flex align-items-center" role="alert">
                                        <?php echo e(Session::get('delete_customer')); ?>

                                        
                                    </div>
                                <?php endif; ?>
                                <tr class='table-info'>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                    <th>Email</th>
                                    <th>Country</th>
                                    <th>City</th>
                                    <th>Company</th>
                                    <th>Photo</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody  class="">
                                <tr>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($cus->id); ?></td>
                                    <td><?php echo e($cus->name); ?></td>
                                    <td><?php echo e($cus->mobile); ?></td>
                                    <td><?php echo e($cus->email); ?></td>
                                    <td><?php echo e($cus->country_id); ?></td>
                                    <td><?php echo e($cus->city_id); ?></td>
                                    <td><?php echo e($cus->company); ?></td>
                                    <td><img src="<?php echo e(asset('img/product')); ?>/<?php echo e($cus->photo); ?>" width='70' alt="<?php echo e($cus->photo); ?>"></td>
                                    <td>

                                        <div style="display:flex">
                                            <a href="<?php echo e(route('customers.show',$cus->id)); ?>" style="padding:2px; border:1px solid hsl(177, 88%, 74%);"><i class="fa fa-eye btn btn-info" style="padding: 10px; "></i></a>
                                            <a href="<?php echo e(route('customers.edit',$cus->id)); ?>" style="padding:2px; border:1px solid hsl(177, 82%, 74%);"><i class="fa fa-pencil-square-o btn btn-success" style="padding: 10px; "></i></a>
                                            <a href="/delete-customer/<?php echo e($cus->id); ?>" style="padding:2px; border:1px solid hsl(177, 67%, 65%);"><i class="fa fa-trash btn btn-danger" style="padding: 10px;"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                        
                    </div>
                    
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project1\resources\views/pages/customer/manage_customer.blade.php ENDPATH**/ ?>