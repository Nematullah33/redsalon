
<?php $__env->startSection('content'); ?>
<style>
    .table td{
        padding: 10px;
    } 
    .table th {
    padding: 10px;
    }

</style>
<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('employee.create')); ?>">
                        <h5><i class="fa fa-plus btn btn-primary">  New Buyer</i></h5>
                    </a>
                    
                    <div class="card-header-right">
                        <ul class="list-unstyled card-option">
                            <li><i class="fa fa fa-wrench open-card-option"></i></li>
                            <li><i class="fa fa-window-maximize full-card"></i></li>
                            <li><i class="fa fa-minus minimize-card"></i></li>
                            <li><i class="fa fa-refresh reload-card"></i></li>
                            <li><i class="fa fa-trash close-card"></i></li>
                        </ul>
                    </div>
                </div>
                <div class="card-block table-border-style">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped">
                            <thead>
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(Session::get('success')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-lebel="Close"></button>
                                    </div>
                                <?php endif; ?>
                                <tr class='table-info'>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                    <th>Email</th>
                                    <th>Country</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody  class="">
                                <tr>
                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($cus->id); ?></td>
                                    <td><?php echo e($cus->name); ?></td>
                                    <td><?php echo e($cus->mobile); ?></td>
                                    <td><?php echo e($cus->email); ?></td>
                                    <td><?php echo e($cus->country); ?></td>
                                    <td>

                                        
                                        <form action="<?php echo e(route('employee.destroy',$cus->id)); ?>" method="POST">
   
                                            <a class="btn btn-info" href="<?php echo e(route('employee.show',$cus->id)); ?>">Show</a>
                            
                                            <a class="btn btn-primary" href="<?php echo e(route('employee.edit',$cus)); ?>">Edit</a>
                           
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                              
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                        
                    </div>
                    
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\redsalon\resources\views/pages/employee/manage_emp.blade.php ENDPATH**/ ?>