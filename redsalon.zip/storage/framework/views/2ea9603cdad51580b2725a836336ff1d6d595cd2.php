
<?php $__env->startSection('content'); ?>
<div style="width:250px; padding:20px; height:300px; background-color:blue; color:#fff; margin: 0px auto; border:2px solid #f7b407;">
    <table style="">
        <tr>
            <th></th>
            <td></td>
            <td><img src="<?php echo e(asset('img')); ?>/<?php echo e($user[0]->photo); ?>" class='img-thumbnail' width='100' alt=""></td>
        </tr>
        <tr>
            <th style="text-align:right">ID </th>
            <td>:</td>
            <td><?php echo e($user[0]->id); ?></td>
        </tr>

        <tr>
            <th style="text-align:right">Name </th>
            <td>:</td>
            <td><?php echo e($user[0]->username); ?></td>
        </tr>
        <tr>
            <th style="text-align:right">Email </th>
            <td>:</td>
            <td><?php echo e($user[0]->email); ?></td>
        </tr>
        <tr>
            <th style="text-align:right">Role </th>
            <td>:</td>
            <td><?php echo e($user[0]->role); ?></td>
        </tr>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project\resources\views/pages/user/details_user.blade.php ENDPATH**/ ?>