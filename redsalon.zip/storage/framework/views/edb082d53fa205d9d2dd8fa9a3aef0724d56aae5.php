
<?php $__env->startSection('content'); ?>
<style>
    .table td{
        padding: 10px;
    } 
    .table th {
    padding: 10px;
    }

</style>
<div class="row">
    <div class="col-md-8">
        <div class="pcoded-inner-content">
            <!-- Main-body start -->
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo e(route('employee.index')); ?>">
                                <h5><i class="fa fa-plus btn btn-primary">Manage Employee</i></h5>
                            </a>
                            
                            <div class="card-header-right">
                                <ul class="list-unstyled card-option">
                                    <li><i class="fa fa fa-wrench open-card-option"></i></li>
                                    <li><i class="fa fa-window-maximize full-card"></i></li>
                                    <li><i class="fa fa-minus minimize-card"></i></li>
                                    <li><i class="fa fa-refresh reload-card"></i></li>
                                    <li><i class="fa fa-trash close-card"></i></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-block table-border-style">
                            <div class="table-responsive">

                                <table class="table table-hover table-striped">

                                    <tr class='table-info'>
                                        <th>ID</th>
                                        <th>:</th>
                                        <th><?php echo e($emp->id); ?></th>
                                    </tr>
                                    <tr>
                                        <th>Name</th>
                                        <th>:</th>
                                        <th><?php echo e($emp->name); ?></th>
                                    </tr>
                                    <tr>
                                        <th>Mobile</th>
                                        <th>:</th>
                                        <th><?php echo e($emp->mobile); ?></th>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <th>:</th>
                                        <th><?php echo e($emp->email); ?></th>
                                    </tr>
                                
                                
                                </table>
                                
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project2\resources\views/pages/employee/details_emp.blade.php ENDPATH**/ ?>