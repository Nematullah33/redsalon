<!-- <form action="<?php echo e(url('user/save')); ?>" method="post"> -->
    
    <?php $__env->startSection('content'); ?>
    <style>
        select.form-control:not([size]):not([multiple]) {
        height: 36px; !important;
         } 
    </style>  
    <div class="pcoded-inner-content">
        <!-- Main-body start -->
        <div class="main-body">
            <div class="page-wrapper">
    
                <!-- Page body start -->
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-2"></div>
                        <div class="col-sm-8">
                            <!-- Basic Form Inputs card start -->
                            <div class="card">
                                <div class="card-header">
                                    <h5><a href="<?php echo e(url('services')); ?>">Manage Service</a></h5>
                                </div>
                                <div class="card-block">
                                            <?php if(Session::has('update_service')): ?>
                                                <div class="alert alert-success d-flex align-items-center" role="alert">
                                                    <?php echo e(Session::get('update_service')); ?>

                                                    
                                                </div>
                                            
                                            <?php endif; ?>
                                    <form action="<?php echo e(route('services.update',$service->id)); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="form-group row">
                                            <input type="hidden" value="<?php echo e($service->id); ?>" name='id'>
                                            <label class="col-sm-3 col-form-label">Service Name</label>
                                            <div class="col-sm-9">
                                                <input type="text" name='txtName'
                                                    class="form-control " value="<?php echo e($service->name); ?>" placeholder="category Name" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group row"> 
                                            <label class="col-sm-3 col-form-label">Category Name</label>
                                            <div class="col-sm-9">
                                                <select id="cmbCategory" name="cmbCategory" class="form-control"
                                                        style='border:1px solid #ccc;'>
                                                        <option style="padding:0px;">Select Category</option>
                                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($service->category_id==$cat->id): ?>
                                                                <option value="<?php echo e($cat->id); ?>" selected='selected'><?php echo e($cat->name); ?></option>
                                                                <?php else: ?>
                                                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row"> 
                                            <label class="col-sm-3 col-form-label">Service Price </label>
                                            <div class="col-sm-9">
                                                <input type="text" name='price'
                                                    class="form-control" placeholder="0.00" value="<?php echo e($service->price); ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Service Photo</label>
                                            <div class="col-sm-9">
                                                <input type="file" name='filePhoto' class="form-control ">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Service Description</label>
                                            <div class="col-sm-9">
                                                <textarea name="description" id="description"  class="form-control"><?php echo e($service->description); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
    
                                            <div class="col-sm-12">
                                                <input type="submit" name='btnCreate'
                                                    class="form-control  btn-primary" style='background-color:#E9118F'  value='Submit'>
                                            </div>
                                        </div>
    
                                    </form>
                                </div>
                            </div>
                            <!-- Basic Form Inputs card end -->
                        </div>
                    </div>
                </div>
                <!-- Page body end -->
    
            </div>
    
        </div>
    </div>
        <!-- Main-body end -->
        <div id="styleSelector">
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\redsalon\resources\views/pages/service/edit_service.blade.php ENDPATH**/ ?>