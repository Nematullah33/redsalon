
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-md-8">
			<div  class="card">
				<div  class="card-header">
					<h5><a href="<?php echo e(url('/payments')); ?>">Manage Payments</a></h5>
					
				</div>
				<div  class="card-body">
					<form action="<?php echo e(route('payments.store')); ?>" method="post" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<?php echo select_field(["label"=>"Customer Id","id"=>"cmbCustomer","name"=>"cmbCustomer","table"=>$customers]); ?>

						<?php echo input_field(["label"=>"Amount","name"=>"txtAmount"]); ?>

						<?php echo select_field(["label"=>"Bank Id","name"=>"cmbBank","table"=>$banks]); ?>

						<?php echo input_field(["label"=>"Payment Date","type"=>"date","name"=>"txtPayment_date"]); ?>

						<?php echo input_field(["label"=>"Payment Note","name"=>"txtPayment_note"]); ?>

						<?php echo input_button(["type"=>"submit","name"=>"btnCreate","value"=>"Create"]); ?>

					</form>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="card">
				<div class="card-header"></div>
				<div class="card-body">
					<table class="table-bordered payments">
						

					</table>
				</div>
				<div class="card-header"></div>
			</div>
		</div>
	</div>
</div>
<script>
$(function(){
	$("#cmbCustomer").on("change",function(){
		let id=$(this).val();
		$.ajax({
                url:"<?php echo e(route('get.payment')); ?>",
                type:'get',
                data:{"id":id},
                success:function(res){
					let payment=JSON.parse(res);
					let total_price=0
					for(pay of payment){
						total_price+=pay.price*pay.qty-pay.discount;
						
						$(".payments").html("<tr style='color:green;padding:20px;' class='table table-primary text-white'><td>Inv ID "+pay.id+"</td><td>Total Order</td><td>"+total_price+"</td></tr>")
					}
					
				
                }
        });
	});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project1\resources\views/pages/payment/create_payment.blade.php ENDPATH**/ ?>