<!-- <form action="<?php echo e(url('user/save')); ?>" method="post"> -->

<?php $__env->startSection('content'); ?>

<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">

            <!-- Page body start -->
            <div class="page-body">
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8">
                        <!-- Basic Form Inputs card start -->
                        <div class="card">
                            <div class="card-header">
                                <h5><a href="<?php echo e(url('employee')); ?>">Manage Buyer</a></h5>

                            </div>
                            <div class="card-block">
                                        <?php if(Session::has('save_emp')): ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <?php echo e(Session::get('success')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-lebel="Close"></button>
                                        </div>
                                        <?php endif; ?>
                                <form action="<?php echo e(route('employee.store')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row">
                                        
                                        <label class="col-sm-2 col-form-label">Name</label>
                                        <div class="col-sm-10">
                                            <input type="text" name='txtName'
                                                class="form-control form-control-round" placeholder="Customer Name" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        
                                        <label class="col-sm-2 col-form-label">Mobile</label>
                                        <div class="col-sm-10">
                                            <input type="text" name='txtMobile'
                                                class="form-control form-control-round" placeholder="Mobile" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        
                                        <label class="col-sm-2 col-form-label">Email</label>
                                        <div class="col-sm-10">
                                            <input type="email" name='txtEmail'
                                                class="form-control form-control-round" placeholder="Email" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Country</label>
                                        <div class="col-sm-10">
                                            <select name="cmbCountry" id="">
                                                <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                    <option value="<?php echo e($co->id); ?>"><?php echo e($co->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">

                                        <div class="col-sm-12">
                                            <input type="submit" name='btnCreate'
                                                class="form-control form-control-round btn-primary" value='Submit'>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                        <!-- Basic Form Inputs card end -->
                    </div>
                </div>
            </div>
            <!-- Page body end -->

        </div>

    </div>
</div>
    <!-- Main-body end -->
    <div id="styleSelector">
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project2\resources\views/pages/employee/create_emp.blade.php ENDPATH**/ ?>