
<?php $__env->startSection('content'); ?>
<style>
.table td {
    padding: 10px;
}

.table th {
    padding: 10px;
}
</style>


<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
            <div class="card">
                <div class="card-header">
                    <h5> Reports </h5>

                    <div class="card-header-right">
                        <ul class="list-unstyled card-option">
                            <li><i class="fa fa fa-wrench open-card-option"></i></li>
                            <li><i class="fa fa-window-maximize full-card"></i></li>
                            <li><i class="fa fa-minus minimize-card"></i></li>
                            <li><i class="fa fa-refresh reload-card"></i></li>
                            <li><i class="fa fa-trash close-card"></i></li>
                        </ul>
                    </div>
                </div>
                <div class="card-block table-border-style">
                    <form action="">
                        <div class="form-group row">
                            <div class="col-sm-3">
                                <label class="form-label">From</label>
                                <input type="date" name='formOrder'
                                    class="form-control" value="<?php echo date('Y-m-d');?>" />
                            </div>
                            <div class="col-sm-3">
                                <label class="form-label">To</label>
                                <input type="date" name='toOrder'
                                    class="form-control" value="<?php echo date('Y-m-d');?>"/>
                            </div>
                            <div class="col-sm-3">
                                <div style="margin-bottom:8px;"></div><br>
                                <button type="submit" style="padding: 4px 15px;" class=" btn-outline-primary">Search  <i class="fa fa-search"></i></button>
                                
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(url('reports')); ?>" style="padding: 4px 15px;"  class="btn-outline-primary">Go Back</a>
                            </div>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr class="table-primary text-white">
                                    <th>#</th>
                                    <th>C.Name</th>
                                    <th>Mobile</th>
                                    <th>Order.Date</th>
                                    <th>Order.Total</th>
                                    

                                </tr>
                            </thead>
                            <tbody>
                                
                                <input type="hidden" value="<?php echo e($total=0); ?>">
                                <tr>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->cus_name); ?></td>
                                    <td><?php echo e($order->mobile); ?></td>
                                    <td><?php echo e($order->order_date); ?></td>
                                    <td><?php echo e($order->price*$order->qty); ?></td>
                                    
                                    <input type="hidden" value="<?php echo e($total+=$order->price*$order->qty); ?>">
                                </tr>
                                

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td class="text-right  table-info"><b>Total </b></td>
                                    <td class="table-info"><b><?php echo e($total); ?></b></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project2\resources\views/pages/reports/make_report.blade.php ENDPATH**/ ?>