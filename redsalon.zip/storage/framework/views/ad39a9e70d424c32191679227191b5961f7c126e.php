
<?php $__env->startSection('content'); ?>
<div style="width:250px; padding:20px; height:300px; background-color:blue; color:#fff; margin: 0px auto; border:2px solid #f7b407;">
    <table style="">
        <tr>
            <th></th>
            <td></td>
            <td><img src="<?php echo e(asset('img/product')); ?>/<?php echo e($product[0]->photo); ?>" class='img-thumbnail' width='100' alt=""></td>
        </tr>
        <tr>
            <th style="text-align:right">ID </th>
            <td>:</td>
            <td><?php echo e($product[0]->id); ?></td>
        </tr>

        <tr>
            <th style="text-align:right">Name </th>
            <td>:</td>
            <td><?php echo e($product[0]->name); ?></td>
        </tr>
        <tr>
            <th style="text-align:right">Price </th>
            <td>:</td>
            <td><?php echo e($product[0]->price); ?></td>
        </tr>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project\resources\views/pages/product/details_product.blade.php ENDPATH**/ ?>