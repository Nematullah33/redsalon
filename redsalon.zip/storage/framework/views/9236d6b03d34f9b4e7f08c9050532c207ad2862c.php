<table>
    <tr><th style="text-align:right">User ID </th><td><?php echo e($user[0]->id); ?></td></tr>
    <tr><th  style="text-align:right">Username </th><td><?php echo e($user[0]->username); ?></td></tr>
    <tr><th  style="text-align:right">Email </th><td><?php echo e($user[0]->email); ?></td></tr>
    <tr><th  style="text-align:right">Role </th><td><?php echo e($user[0]->role); ?></td></tr>
</table><?php /**PATH D:\xampp\htdocs\laravel\project\resources\views/user/details_user.blade.php ENDPATH**/ ?>