<!-- <form action="<?php echo e(url('user/save')); ?>" method="post"> -->
    
   <?php $__env->startSection('title', 'Edit Company'); ?> 

    <?php $__env->startSection('content'); ?>
    
    <div class="pcoded-inner-content">
        <!-- Main-body start -->
        <div class="main-body">
            <div class="page-wrapper">
    
                <!-- Page body start -->
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-2"></div>
                        <div class="col-sm-8">
                            <!-- Basic Form Inputs card start -->
                            <div class="card">
                                <div class="card-header">
                                    <h5>Site Settings  /</h5>
                                </div>
                                <div class="card-block">
                                            <?php if(Session::has('update_setting')): ?>
                                                <div class="alert alert-success d-flex align-items-center" role="alert">
                                                    <?php echo e(Session::get('update_setting')); ?>

                                                    
                                                </div>
                                            
                                            <?php endif; ?>
                                    <form action="<?php echo e(route('settings.update',$site->id)); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="form-group row">

                                            <label class="col-sm-3 col-form-label">Name</label>
                                            <div class="col-sm-9">
                                                <input type="text" name='txtName'
                                                    class="form-control " value="<?php echo e($site->name); ?>" placeholder="Customer Name" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            
                                            <label class="col-sm-3 col-form-label">Mobile</label>
                                            <div class="col-sm-9">
                                                <input type="text" name='txtMobile'
                                                    class="form-control " value="<?php echo e($site->mobile); ?>" placeholder="Mobile" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            
                                            <label class="col-sm-3 col-form-label">Email</label>
                                            <div class="col-sm-9">
                                                <input type="email" name='txtEmail'
                                                    class="form-control " value="<?php echo e($site->email); ?>" placeholder="Email" autocomplete="off">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row">
                                        
                                            <label class="col-sm-3 col-form-label">Address</label>
                                            <div class="col-sm-9">
                                                <textarea name='address' class='form-control'><?php echo e($site->address); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 col-form-label">Company Logo</label>
                                            <div class="col-sm-6">
                                                <input type="file" name='filePhoto' class="form-control ">
                                            </div>
                                            <div class="col-sm-3">
                                                <img src="<?php echo e(asset('img/setting')); ?>/<?php echo e($site->photo); ?>" width='100%' height="100%" alt="<?php echo e($site->photo); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group row">
    
                                            <div class="col-sm-3">
                                                <input type="submit" name='btnCreate'
                                                    class="form-control  btn-primary img-thumbnail" style='background-color:#E9118F'  value='Update'>
                                            </div>
                                        </div>
    
                                    </form>
                                </div>
                            </div>
                            <!-- Basic Form Inputs card end -->
                        </div>
                    </div>
                </div>
                <!-- Page body end -->
    
            </div>
    
        </div>
    </div>
        <!-- Main-body end -->
        <div id="styleSelector">
        </div>
        <script>
            $(function(){
                
    
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\redsalon\resources\views/pages/setting/edit_setting.blade.php ENDPATH**/ ?>