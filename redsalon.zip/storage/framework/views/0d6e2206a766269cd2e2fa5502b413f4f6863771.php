
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		
		<div class="col-md-8">
			<div  class="card">
				<div  class="card-header">
					<h5><a href="<?php echo e(url('/payments')); ?>">Manage Payments</a></h5>
					
				</div>
				<div  class="card-body">
					<form action="<?php echo e(route('payments.update',$payment)); ?>" method="post" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<?php echo method_field("PUT"); ?>
						<?php echo select_field(["label"=>"Customer Id","name"=>"cmbCustomer","table"=>$customers,"value"=>$payment->customer_id]); ?>

						<?php echo input_field(["label"=>"Amount","name"=>"txtAmount","value"=>$payment->amount]); ?>

						<?php echo select_field(["label"=>"Bank Id","name"=>"cmbBank","table"=>$banks,"value"=>$payment->bank_id]); ?>

						<?php echo input_field(["label"=>"Payment Date","name"=>"txtPayment_date","value"=>$payment->payment_date]); ?>

						<?php echo input_field(["label"=>"Payment Note","name"=>"txtPayment_note","value"=>$payment->payment_note]); ?>

						<?php echo input_field(["label"=>"Created At","name"=>"txtCreated_at","value"=>$payment->created_at]); ?>

						<?php echo input_field(["label"=>"Updated At","name"=>"txtUpdated_at","value"=>$payment->updated_at]); ?>

					
						<?php echo input_button(["type"=>"submit","name"=>"btnUpdate","value"=>"Update"]); ?>

					</form>
				</div>
			</div>
		</div>
		<div class="col-md-4"></div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project2\resources\views/pages/payment/edit_payment.blade.php ENDPATH**/ ?>