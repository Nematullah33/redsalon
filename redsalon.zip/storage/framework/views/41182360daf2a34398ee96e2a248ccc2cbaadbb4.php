
<?php $__env->startSection('content'); ?>

<a class='btn btn-success' href="<?php echo e(route('suppliers.index')); ?>">Manage</a>
<table class='table'>
	<tr><th>Id</th><td><?php echo e($supplier->id); ?></td></tr>
	<tr><th>Name</th><td><?php echo e($supplier->name); ?></td></tr>
	<tr><th>Mobile</th><td><?php echo e($supplier->mobile); ?></td></tr>
	<tr><th>Country Id</th><td><?php echo e($supplier->country_id); ?></td></tr>
	<tr><th>City Id</th><td><?php echo e($supplier->city_id); ?></td></tr>
	<tr><th>Area Id</th><td><?php echo e($supplier->area_id); ?></td></tr>
	<tr><th>Photo</th><td><img src="img/<?php echo e($supplier->photo); ?>" width="150" /></td></tr>
	<tr><th>Email</th><td><?php echo e($supplier->email); ?></td></tr>
	<tr><th>Company</th><td><?php echo e($supplier->company); ?></td></tr>
	<tr><th>Created At</th><td><?php echo e($supplier->created_at); ?></td></tr>
	<tr><th>Updated At</th><td><?php echo e($supplier->updated_at); ?></td></tr>

</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project2\resources\views/pages/supplier/show_supplier.blade.php ENDPATH**/ ?>