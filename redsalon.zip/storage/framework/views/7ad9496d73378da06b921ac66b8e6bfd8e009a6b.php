<!-- <form action="<?php echo e(url('user/save')); ?>" method="post"> -->

<?php $__env->startSection('content'); ?>
<style>
    .lc-table,tr,td{
        padding: 10px;
    }
    .lc-table,tr{
       
    }
</style>
<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">

            <!-- Page body start -->
            <div class="page-body">
                <div class="row">

                    <div class="col-sm-12">
                        <!-- Basic Form Inputs card start -->
                        <div class="card" style="margin-bottom: 5px;">
                            <div class="card-header">
                            </div>
                            <div class="card-block" style="padding-bottom: 5px;">
                                <?php if(Session::has('save_bank')): ?>
                                <div class="alert alert-success d-flex align-items-center" role="alert">
                                    <?php echo e(Session::get('save_bank')); ?>  
                                </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('lc.store')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="table-responsive">
                                        <table style="width: 100%" class="lc-table table-striped">
                                            <tr>
                                                <td>LC ID</td>
                                                <td>:</td>
                                                <td><input type="text" value="<?php echo e($inv_id[0]->id+1); ?>" class="form-control" readonly>
                                                </td>  
                                                <td>LC Issu Date</td>
                                                <td>:</td>
                                                <td><input type="text" name='issuDate' id='issuDate' value="<?php echo date("d-m-Y");?>" class="form-control  form-control-round"
                                                    placeholder="Bank Name" autocomplete="off">
                                                </td> 
                                            </tr>
                                            <tr>
                                                <td>Invoice ID</td>
                                                <td>:</td>
                                                <td><input type="number" name='txtInvoice' id='txtInvoice' class="form-control"
                                                    placeholder="" autocomplete="off">
                                                </td>

                                                <td>Buyer Name</td>
                                                <td>:</td>
                                                <td>
                                                    <input type="text" id="txtBuyer" class="form-control">
                                                    <input type="hidden" id="buyerId" name="buyerId" class="form-control">
                                                </td> 
                                            </tr>
                                            <tr>
                                                <td>Party Name</td>
                                                <td>:</td>
                                                <td><input type="text" name='txtParty' id='txtBank' class="form-control"
                                                    placeholder="party Name" autocomplete="off">
                                                </td>
    
                                                <td>Buyer Bank</td>
                                                <td>:</td>
                                                <td>
                                                    <select name="f_bank" id="f_bank" class="form-control">
                                                        <?php $__currentLoopData = $f_banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Local Bank</td>
                                                <td>:</td>
                                                <td>
                                                    <select name="l_bank" id="l_bank" class="form-control">
                                                        <?php $__currentLoopData = $l_banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>Shipment Cost</td>
                                                <td>:</td>
                                                <td><input type="number" name='shipmentCost' id='shipmentCost'  class="form-control"
                                                     autocomplete="off">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Shipment Date</td>
                                                <td>:</td>
                                                <td><input type="text" name='shipmentDate' id='shipmentDate' value="<?php echo date("d-m-Y");?>" class="form-control"
                                                     autocomplete="off">
                                                </td>
                                                <td>Total LC Amt</td>
                                                <td>:</td>
                                                <td><input type="text" name='txtAmt' id='txtAmt' class="form-control"
                                                    autocomplete="off">
                                                </td>
                                                
                                            </tr>
                                        </table>
                                    </div>
                                    
                                    <div>
                                        <button id="lc-confirm" type="submit" class="btn btn-lg btn-info btn-block">
                                            <i class="fa fa-lock fa-lg"></i>&nbsp;
                                            <span id="payment-button-amount">Ready LC</span>
                                            <span id="payment-button-sending" style="display:none;">Sending…</span>
                                        </button>
                                    </div>
                                    
                                </form>
                                <hr>
                                <div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table  style="width: 100%">
                                                    <thead class="invoice-head">
                    
                                                    </thead>
                                                    <tbody id="invoice-details"></tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>  
                        </div>
                        <!-- Basic Form Inputs card end -->
                    </div>
                </div>
                
            </div>
            <!-- Page body end -->


            <!-- Main-body start -->

        </div>
    </div>
</div>
<!-- Main-body end -->
<div id="styleSelector">
</div>
<script>
    $(function(){
        $("#issuDate").datepicker({
        dateFormat: 'dd-mm-yy'
        });
        $("#shipmentDate").datepicker({
        dateFormat: 'dd-mm-yy'
        });
        $("#expiryDate").datepicker({
        dateFormat: 'dd-mm-yy'
        });


        $("#shipmentCost").on('blur',function(){
            let cost=parseInt($(this).val());
            let amt=parseInt($("#txtAmt").val());
            let total=cost+amt;
            $("#txtAmt").val(total);
        });


        $("#txtInvoice").on('blur',function(){
            let invoice_no=$(this).val();
            //alert(invoice_no);
            $.ajax({
             url:"<?php echo e(route('get-invoice')); ?>",
             type:'get',
             data:{"id":invoice_no},
             success:function(res){
               //console.log(res);
              let invoice=JSON.parse(res);
               //console.log(invoice);
                    
                    $(".invoice-head").html("<tr style='background-color:#000; border:2px solid red; font-weight:bold; color:#fff;'><th style='padding-left:10px;'>SN</td><th style='padding-left:10px;'>Product Name</td><td>Price</td><td>Quantity</td><td>discount</td><td>Sub Total</td></tr>");
                    let total_price=0;
                    let html="";
                    let sn="";
                    
               for(inv of invoice){
                    $("#buyerId").val(inv.id);
                    $("#txtBuyer").val(inv.name);
                    
                    sn++;
                    total_price+=inv.price*inv.qty-inv.discount;
                    subtotaltal=inv.price*inv.qty-inv.discount;
                    $("#txtAmt").val(total_price);
                    
                    html+="<tr style='border:1px solid #eee;'><td>"+sn+"</td><td>"+inv.product_name+"</td><td>"+inv.price+"</td><td>"+inv.qty+"</td><td>"+inv.discount+"</td><td>"+subtotaltal+"</td></tr>";
                    
               }
               $("#invoice-details").html(html);
               
             }
           });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project1\resources\views/pages/lc/create_lc.blade.php ENDPATH**/ ?>