
<?php $__env->startSection('content'); ?>
<style>
.table td {
    padding: 10px;
}

.table th {
    padding: 10px;
}
</style>
<div class="addEmployeeModal modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="user_form">
                <div class="modal-header">
                    <h4 class="modal-title">Update Status</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">

                <select id="cmbStatus" name="cmbStatus" class="form-control" >
                    <option value="1">On Process</option>
                    <option value="2">On the way</option>
                    <option value="3">Delidered</option>
                </select>

                </div>
                <div class="modal-footer">
                    <input type="hidden" value="1" name="type">
                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                    <button type="button" class="btn btn-success" id="btnSubmit">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('order.create')); ?>">
                        <h5><i class="fa fa-plus btn btn-primary">  New Order </i></h5>
                    </a>

                    <div class="card-header-right">
                        <ul class="list-unstyled card-option">
                            <li><i class="fa fa fa-wrench open-card-option"></i></li>
                            <li><i class="fa fa-window-maximize full-card"></i></li>
                            <li><i class="fa fa-minus minimize-card"></i></li>
                            <li><i class="fa fa-refresh reload-card"></i></li>
                            <li><i class="fa fa-trash close-card"></i></li>
                        </ul>
                    </div>
                </div>
                <div class="card-block table-border-style">
                    <form action="">
                        <div class="form-group row">
                            <div class="col-sm-3">
                                <label class="form-label">From</label>
                                <input type="date" name='formOrder'
                                    class="form-control" value="<?php echo date('Y-m-d');?>" />
                            </div>
                            <div class="col-sm-3">
                                <label class="form-label">To</label>
                                <input type="date" name='toOrder'
                                    class="form-control" value="<?php echo date('Y-m-d');?>"/>
                            </div>
                            <div class="col-sm-3">
                                <div style="margin-bottom:8px;"></div><br>
                                <button type="submit" style="padding: 4px 15px;" class=" btn-outline-primary">Search  <i class="fa fa-search"></i></button>
                                
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo e(url('order')); ?>" style="padding: 4px 15px;"  class="btn-outline-primary">Go Back</a>
                            </div>
                        </div>
                    </form>

                    <?php if(Session::has('delete_order')): ?>
                            <div class="alert alert-success d-flex align-items-center" role="alert">
                            <?php echo e(Session::get('delete_order')); ?>        
                            </div>
                        <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-striped">
                            <thead>
                                <tr class='table-info'>
                                    <th>#</th>
                                    <th>C.Name</th>
                                    <th>Mobile</th>
                                    <th>Order.Date</th>
                                    <th>Order.Total</th>
                                    <th>Delivery.Date</th>
                                    <th>Note</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <tr>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->cus_name); ?></td>
                                    <td><?php echo e($order->mobile); ?></td>
                                    <td><?php echo e($order->order_date); ?></td>
                                    <td><?php echo e($order->order_total); ?></td>
                                    <td><?php echo e($order->delivery_date); ?></td>
                                    <td><?php echo e($order->customer_note); ?></td>
                                    <?php if($order->status_id==1): ?>
                                    <td ><a href=".addEmployeeModal" style="border-radius:20px;" data-id="<?php echo e($order->id); ?>" class="btn btn-outline-success btn-sm btnUpdate" data-toggle="modal"> On Process</a></td>
                                    <?php elseif($order->status_id==2): ?>
                                    <td ><a href=".addEmployeeModal" style="border-radius:20px;" data-id="<?php echo e($order->id); ?>" class="btn btn-outline-primary btn-sm btnUpdate" data-toggle="modal"> On the way</a></td>
                                    <?php elseif($order->status_id==3): ?>
                                    <td ><a href=".addEmployeeModal" style="border-radius:20px;" data-id="<?php echo e($order->id); ?>" class="btn btn-outline-info btn-sm btnUpdate" data-toggle="modal"> Delivered</a></td>
                                    <?php endif; ?>
                                    
                                    <td>
                                        <div style="display:flex">
                                            <button style='border:none;  padding:5px;'
                                                class="btn btn-default waves-effect" data-toggle="tooltip"
                                                data-placement="top" title="" data-original-title="To Update User"><a
                                                    href="<?php echo e(route('order.edit',$order->id)); ?>"><i
                                                        class='fa fa-pencil'></i> Edit<a></button>
                                            <button style='border:none;  padding:5px;'
                                                class="btn btn-default waves-effect" data-toggle="tooltip"
                                                data-placement="top" title="" data-original-title="View User Details">
                                                <a href="<?php echo e(route('order.show',$order->id)); ?>"><i class='fa fa-eye'></i>
                                                    Details<a></button>
                                            <button style='border:none;'>
                                                <form action="<?php echo e(route('order.destroy',$order->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field("DELETE"); ?>
                                                    <i class='fa fa-trash'></i><input type="submit" name="btnDelete"
                                                        value="Delete" style='border:none; padding:6px;'
                                                        class="btn btn-default waves-effect" data-toggle="tooltip"
                                                        data-placement="top" title=""
                                                        data-original-title="To Delete User" />
                                                </form>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <input type="hidden" name="" id="order_id">
        </div>
    </div>
</div>
<script>
    $(function(){
        $(".btnUpdate").on('click',function(){
            let order_id=$(this).data("id");
            $("#order_id").val(order_id);

        });
        
        $("#btnSubmit").on('click',function(){
            let id=$("#order_id").val(); 
            let status_id=$("#cmbStatus").val();
            
            $.ajax({
                url:"<?php echo e(route('update.order_status')); ?>",
                type:'get',
                data:{"status_id":status_id,"order_id":id},
                success:function(res){
                   
                 location.reload();
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project2\resources\views/pages/order/manage.blade.php ENDPATH**/ ?>