
<?php $__env->startSection('content'); ?>

<a class='btn btn-success' href="<?php echo e(url('/suppliers')); ?>">Manage</a>
<form action="<?php echo e(route('suppliers.store')); ?>" method="post" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<?php echo input_field(["label"=>"Name","name"=>"txtName"]); ?>

	<?php echo input_field(["label"=>"Mobile","name"=>"txtMobile"]); ?>

	<?php echo select_field(["label"=>"Country Id","name"=>"cmbCountry","table"=>$countrys]); ?>

	<?php echo select_field(["label"=>"City Id","name"=>"cmbCity","table"=>$citys]); ?>

	<?php echo select_field(["label"=>"Area Id","name"=>"cmbArea","table"=>$areas]); ?>

	<?php echo input_field(["label"=>"Photo","type"=>"file","name"=>"filePhoto"]); ?>

	<?php echo input_field(["label"=>"Email","name"=>"txtEmail"]); ?>

	<?php echo input_field(["label"=>"Company","name"=>"txtCompany"]); ?>

	<?php echo input_field(["label"=>"Created At","name"=>"txtCreated_at"]); ?>

	<?php echo input_field(["label"=>"Updated At","name"=>"txtUpdated_at"]); ?>


	<?php echo input_button(["type"=>"submit","name"=>"btnCreate","value"=>"Create"]); ?>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.erp.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\project2\resources\views/pages/supplier/create_supplier.blade.php ENDPATH**/ ?>